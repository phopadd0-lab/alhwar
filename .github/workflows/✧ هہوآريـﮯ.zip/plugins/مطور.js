// plugins/custom_rich.js
// ✧ هہوآريـﮯ - قالب رسائل Meta AI التفاعلية ✨

let handler = async (m, { conn }) => {
  try {
    const payload = {
      "__typename": "GenAIUnifiedResponse",
      "response_id": `test_${Date.now()}`,
      "sections": [
        {
          "__typename": "GenAIUnifiedResponseSection",
          "view_model": {
            "__typename": "GenAISingleLayoutViewModel",
            "primitive": {
              "__typename": "GenAIImaginePrimitive",
              "imagine_type": "IMAGE",
              "media": {
                "url": "https://raw.githubusercontent.com/B7R-V/UPLOADS-B7R/main/uploads/OoCx8.jpeg", // رابط الصورة العلوية
                "mime_type": "image/jpeg",
                "width": 16,
                "height": 9
              },
              "status": { "status": "READY" }
            }
          }
        },
        {
          "__typename": "GenAIUnifiedResponseSection",
          "view_model": {
            "__typename": "GenAISingleLayoutViewModel",
            "primitive": {
              "__typename": "GenAICompactEntityPrimitive",
              "title": "العنوان الرئيسي",
              "subtitle": "العنوان الفرعي",
              "secondary_subtitle": "الوصف الإضافي",
              "entity_id": 867051314767696,
              "entity_url": "https://tiktok.com/@rolenzo.0", // رابط المتابعة/الزر
              "entity_type": "PAGE",
              "action_type": "FOLLOW",
              "is_verified": true,
              "image": {
                "url": "https://raw.githubusercontent.com/B7R-V/UPLOADS-B7R/main/uploads/i6L3T.jpeg", // رابط الصورة المصغرة
                "url_fallback": "https://raw.githubusercontent.com/B7R-V/UPLOADS-B7R/main/uploads/i6L3T.jpeg"
              }
            }
          }
        }
      ]
    }

    // تحويل البيانات إلى Base64
    const base64Data = Buffer.from(JSON.stringify(payload)).toString('base64')

    // إرسال الرسالة عبر relayMessage
    await conn.relayMessage(
      m.chat,
      {
        "message": {
          "richResponseMessage": {
            "messageType": "AI_RICH_RESPONSE_TYPE_STANDARD",
            "unifiedResponse": {
              "data": base64Data
            },
            "contextInfo": {
              "forwardingScore": 1,
              "isForwarded": true,
              "forwardOrigin": "META_AI"
            }
          }
        }
      },
      { quoted: m }
    )

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-RichMessage] Error:', e)
  }
}

handler.help = ['مطور ']
handler.tags = ['القسم']
handler.command = ['مطور ']

export default handler