// plugins/owner_rich.js
// ✧ هہوآريـﮯ - أمر المطور بصيغة Meta AI Rich Response ✨

let handler = async (m, { conn }) => {
  try {
    const payload = {
      "__typename": "GenAIUnifiedResponse",
      "response_id": `test_${Date.now()}`,
      "sections": [
        {
          "__typename": "GenAIUnifiedResponseSection",
          "view_model": {
            "__typename": "GenAISingleLayoutViewModel",
            "primitive": {
              "__typename": "GenAIImaginePrimitive",
              "imagine_type": "IMAGE",
              "media": {
                "url": "https://raw.githubusercontent.com/B7R-V/UPLOADS-B7R/main/uploads/OoCx8.jpeg",
                "mime_type": "image/jpeg",
                "width": 16,
                "height": 9
              },
              "status": { "status": "READY" }
            }
          }
        },
        {
          "__typename": "GenAIUnifiedResponseSection",
          "view_model": {
            "__typename": "GenAISingleLayoutViewModel",
            "primitive": {
              "__typename": "GenAICompactEntityPrimitive",
              "title": "هہ‏‏وآريـﮯ",
              "subtitle": "مالك ومطور النظام",
              "secondary_subtitle": "TikTok Creator",
              "entity_id": 867051314767696,
              "entity_url": "https://tiktok.com/@rolenzo.0",
              "entity_type": "PAGE",
              "action_type": "FOLLOW",
              "is_verified": true,
              "image": {
                "url": "https://raw.githubusercontent.com/B7R-V/UPLOADS-B7R/main/uploads/i6L3T.jpeg",
                "url_fallback": "https://raw.githubusercontent.com/B7R-V/UPLOADS-B7R/main/uploads/i6L3T.jpeg"
              }
            }
          }
        }
      ]
    }

    // تحويل البيانات إلى Base64
    const base64Data = Buffer.from(JSON.stringify(payload)).toString('base64')

    // إرسال الرسالة التفاعلية عبر relayMessage
    await conn.relayMessage(
      m.chat,
      {
        "message": {
          "richResponseMessage": {
            "messageType": "AI_RICH_RESPONSE_TYPE_STANDARD",
            "unifiedResponse": {
              "data": base64Data
            },
            "contextInfo": {
              "forwardingScore": 1,
              "isForwarded": true,
              "forwardOrigin": "META_AI"
            }
          }
        }
      },
      { quoted: m }
    )

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-OwnerRich] Error:', e)
    m.reply('❌ حدث خطأ أثناء إرسال بطاقة المطور.')
  }
}

handler.help = ['owner']
handler.tags = ['main']
handler.command = ['meta', 'مطور', 'المطور', 'owner']

export default handler