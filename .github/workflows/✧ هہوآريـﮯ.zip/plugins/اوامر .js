// plugins/menu.js
// ✧ 2B - YoRHa Unit No.2 Type B - القائمة الرئيسية ❄️

import { performance } from 'perf_hooks'
import fetch from 'node-fetch'
import { ButtonV2 } from '../core/NIXCODE.js'

const menuCooldown = {}

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    let old = performance.now()
    let neww = performance.now()
    let speed = (neww - old).toFixed(4)

    const user = await conn.getName(m.sender)
    const fecha = new Date().toLocaleDateString('ar-SA', { 
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
    })
    const hora = new Date().toLocaleTimeString('ar-SA')

    let menuText = `   ⃝⃘︢︣֟፝ · ͟͟͞͞𝐘𝐨𝐑𝐇𝐚· ͟͟͞͞➳ 𝟐𝐁
𓉘᳟ี ⃞̸͢𑁃 ̚𓉝᳟ี ͟͟͞͞┄꯭๋━┄꫶︦┄꯭๋━┄꫶︦┄꯭๋━┄꫶︦━┄꫶︦┄꯭๋━┄꯭๋━┄꫶︦┤
│
│ ❄️ *مـعـلـومـات الـوحـدة*
│
│ ❄️ ═══════════════ ❄️
├ׁ̟̇˚₊· ͟͟͞͞➳❥ الاسـم: ${user}
├ׁ̟̇˚₊· ͟͟͞͞➳❥ الـرقـم: ${m.sender.split('@')[0]}
├ׁ̟̇˚₊· ͟͟͞͞➳❥ الـبـيـنـج: ${speed}ms
├ׁ̟̇˚₊· ͟͟͞͞➳❥ الـتـشـغـيـل: ${await getUptime()}
├ׁ̟̇˚₊· ͟͟͞͞➳❥ الـتـاريـخ: ${fecha}
├ׁ̟̇˚₊· ͟͟͞͞➳❥ الـوقـت: ${hora}
│
│ ❄️ ═══════════════ ❄️
│ 🔮 *اخـتـر الـقـسـم مـن الأسـفـل*
│
𓉘᳟ี ⃞̸͢𑁃 ̚𓉝᳟ี ͟͟͞͞┄꯭๋━┄꫶︦┄꯭๋━┄꫶︦┄꯭๋━┄꫶︦━┄꫶︦┄꯭๋━┄꯭๋━┄꫶︦╯`

    await conn.sendMessage(m.chat, { react: { text: '❄️', key: m.key } })

    // ═══════════════════════════════════════
    // 🎯 القائمة الرئيسية - أزرار عائمة
    // ═══════════════════════════════════════
    await new ButtonV2(conn)
      .setBody(menuText)
      .setFooter('❄️ 2B - YoRHa Unit No.2 Type B ❄️')
      .setThumbnail('https://file.garden/aauvg01sjleV_ic1/c838e369caac3173de1f3e0cfbeed415%20(1).jpg')
      .addRawButton({
        buttonText: { displayText: '📂 الأقـسـام الـرئـيـسـيـة' },
        buttonId: 'menu',
        type: 1,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: "اخـتـر الـقـسـم",
            sections: [{
              title: "❄️ الأقـسـام",
              rows: [
                { title: "👮‍♂️ قـسـم الأدمن", description: "❄️ 2B - YoRHa Unit", id: ".ق1" },
                { title: "🎨 قـسـم الاسـتـيـكـر", description: "❄️ 2B - YoRHa Unit", id: ".ق2" },
                { title: "🎮 قـسـم الألـعـاب", description: "❄️ 2B - YoRHa Unit", id: ".ق3" },
                { title: "📥 قـسـم الـتـحـمـيـلات", description: "❄️ 2B - YoRHa Unit", id: ".ق4" },
                { title: "🛠️ قـسـم الأدوات", description: "❄️ 2B - YoRHa Unit", id: ".ق5" },
                { title: "📚 قـسـم الـمـانـجـا", description: "❄️ 2B - YoRHa Unit", id: ".ق6" },
                { title: "🤖 قـسـم الـذكـاء", description: "❄️ 2B - YoRHa Unit", id: ".ق7" },
                { title: "👥 قـسـم الـنـقـابـات", description: "❄️ 2B - YoRHa Unit", id: ".ق8" },
                { title: "🖼️ قـسـم الـصـور", description: "❄️ 2B - YoRHa Unit", id: ".ق9" },
                { title: "🎉 قـسـم الـتـسـلـيـة", description: "❄️ 2B - YoRHa Unit", id: ".ق10" }
              ]
            }]
          })
        }
      })
      .addButton('🤖 تـنـصـيـب وحـدة', '.تنصيب')
      .send(m.chat)

    // ✅ فيديو دائري - كل 10 دقائق
    const now = Date.now()
    if (!menuCooldown[m.chat] || (now - menuCooldown[m.chat]) > 10 * 60 * 1000) {
      menuCooldown[m.chat] = now
      try {
        await conn.sendMessage(m.chat, {
          video: { url: 'https://file.garden/aauvg01sjleV_ic1/snaptik_7640963493004430625_v3.mp4' },
          mimetype: 'video/mp4',
          ptv: true
        }, { quoted: m });
      } catch (videoErr) {}
    }

  } catch (e) {
    console.error('[2B-Menu] Error:', e);
  }
}

async function getUptime() {
  let totalSeconds = process.uptime()
  let hours = Math.floor(totalSeconds / 3600)
  let minutes = Math.floor((totalSeconds % 3600) / 60)
  let seconds = Math.floor(totalSeconds % 60)
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = ['الاوامر', 'menu', 'اوامر', 'القائمة', 'منيو']

export default handler