// plugins/join.js
// ✧ هہ‏‏‏‏وآريـﮯ - انضمام البوت لجروب عن طريق الرابط 🔗

import { ButtonV2 } from '../core/NIXCODE.js'

const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
const footerText = '🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤'

// بناء صندوق منسق
function box(title, lines = []) {
  let out = `┌──────[ ${title} ]──────\n│\n`
  for (let l of lines) out += `├─ ${l}\n`
  out += `│\n└─────────────────────────`
  return out
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    // رد بالشكل الموحد (ButtonV2 لازم فيه زر واحد على الأقل)
    const send = async (body, buttons = [['🔗 انضمام', `${usedPrefix + command}`]]) => {
      let btn = new ButtonV2(conn)
        .setBody(body)
        .setFooter(footerText)
        .setThumbnail(imageUrl)
      for (let [label, cmd] of buttons) btn = btn.addButton(label, cmd)
      await btn.send(m.chat)
    }

    // الرابط من النص أو من الرسالة المرد عليها
    const source = `${text || ''} ${m.quoted?.text || ''}`
    const match = source.match(/chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i)

    if (!match) {
      return send(box('🔗 انضمام لجروب', [
        `⚡ الاستخدام: ${usedPrefix + command} <رابط الجروب>`,
        '📌 أو رد على رسالة فيها الرابط'
      ]))
    }

    const code = match[1]
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
      const groupId = await conn.groupAcceptInvite(code)
      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
      return send(box('✅ تم الانضمام', [
        `🆔 الجروب: ${groupId}`,
        '🤖 البوت الآن داخل الجروب'
      ]), [['📂 القائمة', '.اوامر']])
    } catch (err) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      const msg = String(err?.message || err)
      let reason = 'فشل الانضمام للجروب'
      if (/already/i.test(msg) || /409/.test(msg)) reason = 'البوت موجود في الجروب بالفعل'
      else if (/gone|expired|revoked/i.test(msg) || /410/.test(msg)) reason = 'الرابط منتهي أو تم إلغاؤه'
      else if (/not-authorized|401/i.test(msg)) reason = 'البوت محظور من الجروب'
      else if (/forbidden|403/i.test(msg)) reason = 'الجروب مقفول أو غير متاح'
      else if (/not-found|404/i.test(msg)) reason = 'الرابط غير صحيح'
      else if (/request|approval/i.test(msg)) reason = 'الجروب يحتاج موافقة الأدمن، تم إرسال الطلب'
      return send(box('❌ خطأ', [reason]))
    }

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-Join] Error:', e)
  }
}

handler.help = ['انضم']
handler.tags = ['owner']
handler.command = ['انضم', 'ادخل', 'join']
handler.owner = true

export default handler