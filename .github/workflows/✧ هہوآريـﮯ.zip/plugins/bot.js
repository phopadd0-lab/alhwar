// plugins/bot.js
// ✧ هہ‏‏‏‏وآريـﮯ - معلومات البوت 🔘

import { ButtonV2 } from '../core/NIXCODE.js'

let handler = async (m, { conn, usedPrefix }) => {
  try {
    const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'

    const botText = `┌──────[ 👑 ${global.botName || 'هہ‏‏وآريـﮯ'} 👑 ]──────
│
├─ ⚡ حالة النظام: متصل
├─ ⏱️ مدة التشغيل: ${getUptime()}
│
└─────────────────────────`

    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } })

    await new ButtonV2(conn)
      .setBody(botText)
      .setFooter('🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤')
      .setThumbnail(imageUrl)
      .addButton('📂 القائمة', '.اوامر')
      .addButton('👑 المطور', '.المطور')
      .send(m.chat)

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-Bot] Error:', e)
  }
}

function getUptime() {
  let totalSeconds = process.uptime()
  let hours = Math.floor(totalSeconds / 3600)
  let minutes = Math.floor((totalSeconds % 3600) / 60)
  let seconds = Math.floor(totalSeconds % 60)
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

handler.help = ['bot']
handler.tags = ['main']
handler.customPrefix = /^(\.)?(بوت|bot)$/i
handler.command = new RegExp()

export default handler