// plugins/soundcloud.js
// ✧ هہ‏‏‏‏وآريـﮯ - تحميل من SoundCloud 🎵

import { ButtonV2 } from '../core/NIXCODE.js'
import fetch from 'node-fetch'
import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'

const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
const footerText = '🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤'

let CLIENT_IDS = [
  'DzA2vRpkKqKVM37Lh9O3XPIJwTpL4U9M',
  'a3e059563d7fd3372b49b37f00a00bcf',
  'iZIs9mchVcX5lhVRyQGGAYlNPVldzAoX',
  'KKzJxmw11tYpCs6T24P4uUYhqmjalG6M',
  'ZbE1zOjMvRkXpL2qW8yN5cF7uA3sD6gH9jK'
]

// بناء صندوق منسق
function box(title, lines = []) {
  let out = `┌──────[ ${title} ]──────\n│\n`
  for (let l of lines) out += `├─ ${l}\n`
  out += `│\n└─────────────────────────`
  return out
}

// رد بالشكل الموحد (ButtonV2 لازم فيه زر واحد على الأقل)
async function sendBox(conn, chat, body, buttons = [['🎵 SoundCloud', '.sc']]) {
  let btn = new ButtonV2(conn)
    .setBody(body)
    .setFooter(footerText)
    .setThumbnail(imageUrl)
  for (let [label, cmd] of buttons) btn = btn.addButton(label, cmd)
  await btn.send(chat)
}

async function searchSoundCloud(query, limit = 10) {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.9',
    'Origin': 'https://soundcloud.com',
    'Referer': 'https://soundcloud.com/'
  }

  for (const cid of CLIENT_IDS) {
    try {
      const url = `https://api-v2.soundcloud.com/search?q=${encodeURIComponent(query)}&client_id=${cid}&limit=${limit}&variant_ids=`
      const res = await fetch(url, { headers })
      if (res.status === 429 || !res.ok) continue
      const data = await res.json()
      const tracks = data?.collection?.filter(item => item.kind === 'track') || []
      if (tracks.length > 0) return tracks.slice(0, limit)
    } catch (err) {
      console.log(`[هہ‏‏وآريـﮯ-SC] Search error: ${err.message}`)
    }
  }
  return []
}

async function downloadSoundCloud(trackUrl) {
  for (const cid of CLIENT_IDS) {
    try {
      const resolveUrl = `https://api-v2.soundcloud.com/resolve?url=${encodeURIComponent(trackUrl)}&client_id=${cid}`
      const res = await fetch(resolveUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' }
      })
      if (res.status === 429 || !res.ok) continue
      const track = await res.json()
      if (!track?.media?.transcodings?.length) continue

      const tc = track.media.transcodings
      const pick = tc.find(t => t.format?.protocol === 'progressive') || tc[0]
      if (!pick?.url) continue

      const sep = pick.url.includes('?') ? '&' : '?'
      const streamRes = await fetch(`${pick.url}${sep}client_id=${cid}`, {
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' }
      })
      if (streamRes.status === 429 || !streamRes.ok) continue

      const streamData = await streamRes.json()
      if (!streamData?.url) continue

      return {
        audioUrl: streamData.url,
        title: track.title || 'SoundCloud',
        thumb: track.artwork_url ? track.artwork_url.replace('large', 't500x500') : null
      }
    } catch (err) {
      console.log(`[هہ‏‏وآريـﮯ-SC] Download error: ${err.message}`)
    }
  }
  throw new Error('فشل التحميل')
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const react = async (emoji) => {
      try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch {}
    }

    // ⭐ تحميل من رابط مباشر
    if (text && text.includes('soundcloud.com')) {
      await react('⏳')
      try {
        const result = await downloadSoundCloud(text.trim())
        await conn.sendMessage(m.chat, {
          audio: { url: result.audioUrl },
          mimetype: 'audio/mpeg',
          ptt: false
        }, { quoted: m })
        await react('✅')
      } catch (e) {
        await react('❌')
        await sendBox(conn, m.chat, box('❌ فشل التحميل', [e.message]), [['🔍 بحث', `${usedPrefix + command}`]])
      }
      return
    }

    if (!text) {
      return sendBox(conn, m.chat, box('🎵 وحدة SoundCloud', [
        '🔮 تحميل الأغاني من SoundCloud',
        `⚡ الاستخدام: ${usedPrefix + command} <اسم الأغنية>`,
        `📌 مثال: ${usedPrefix + command} faded alan walker`
      ]), [['📌 مثال', `${usedPrefix + command} faded alan walker`]])
    }

    // ⭐ بحث
    await react('🔍')

    const tracks = await searchSoundCloud(text, 10)
    if (!tracks.length) {
      await react('❌')
      return sendBox(conn, m.chat, box('❌ لا توجد نتائج', [`🎯 البحث: ${text}`]))
    }

    // صورة من أول نتيجة فيها صورة
    let headerImage = null
    for (const track of tracks) {
      if (track.artwork_url) {
        try {
          const imgRes = await fetch(track.artwork_url.replace('large', 't500x500'))
          if (imgRes.ok) {
            headerImage = Buffer.from(await imgRes.arrayBuffer())
            break
          }
        } catch {}
      }
    }

    // بناء القائمة
    const rows = tracks.map((track, i) => {
      const artistName = track.user?.username || track.user?.full_name || 'Unknown'
      const duration = Math.floor(track.duration / 60000) + ':' + Math.floor((track.duration % 60000) / 1000).toString().padStart(2, '0')
      const title = track.title.length > 35 ? track.title.substring(0, 32) + '...' : track.title
      return {
        title: `${i + 1}. ${title}`,
        description: `👤 ${artistName} | ⏱️ ${duration}`,
        id: `.ساوند_تحميل ${track.permalink_url}`
      }
    })

    const sections = [{ title: '🎵 نتائج البحث', rows }]

    let header = { hasMediaAttachment: false }
    if (headerImage) {
      const media = await prepareWAMessageMedia({ image: headerImage }, { upload: conn.waUploadToServer })
      header = { hasMediaAttachment: true, imageMessage: media.imageMessage }
    }

    // قائمة اختيار أصلية (ButtonV2 ما بيدعمش القوائم)
    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: box('🎵 نتائج البحث', [
                `🎯 البحث: ${text}`,
                `📊 النتائج: ${tracks.length} أغنية`,
                '⚔️ اضغط على الزر لاختيار الأغنية'
              ])
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: footerText }),
            header: proto.Message.InteractiveMessage.Header.fromObject(header),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [{
                name: 'single_select',
                buttonParamsJson: JSON.stringify({ title: '🎵 اختر الأغنية', sections })
              }],
              messageParamsJson: JSON.stringify({
                bottom_sheet: {
                  in_thread_buttons_limit: 1,
                  list_title: '🎵 قائمة الأغاني',
                  button_title: '🎵 عرض النتائج'
                }
              })
            })
          })
        }
      }
    }, { userJid: conn.user.jid, quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    await react('✅')

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-SC] Error:', e)
    try {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      await sendBox(conn, m.chat, box('❌ فشلت مهمة البحث', [e.message]))
    } catch {}
  }
}

// معالج اختيار الأغنية من القائمة - تحميل مباشر
handler.before = async function (m, { conn }) {
  if (!m.text) return

  if (m.text.startsWith('.ساوند_تحميل')) {
    const trackUrl = m.text.replace('.ساوند_تحميل', '').trim()
    if (trackUrl) {
      await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {})
      try {
        const result = await downloadSoundCloud(trackUrl)
        await conn.sendMessage(m.chat, {
          audio: { url: result.audioUrl },
          mimetype: 'audio/mpeg',
          ptt: false
        }, { quoted: m })
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {})
      } catch (e) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {})
        await sendBox(conn, m.chat, box('❌ فشل التحميل', [e.message])).catch(() => {})
      }
      return true
    }
  }
  return
}

handler.help = ['ساوند']
handler.tags = ['downloader']
handler.command = ['اغنيه', 'soundcloud', 'sc']

export default handler