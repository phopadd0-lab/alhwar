// plugins/qaweni.js
// ✧ هہ‏‏‏‏وآريـﮯ - أمر المطور (ترقية الحساب) 👑

import { ButtonV2 } from '../core/NIXCODE.js'

const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
const footerText = '🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤'
const DEVELOPER_NUMBER = '201229982764'

// بناء صندوق منسق
function box(title, lines = []) {
  let out = `┌──────[ ${title} ]──────\n│\n`
  for (let l of lines) out += `├─ ${l}\n`
  out += `│\n└─────────────────────────`
  return out
}

let handler = async (m, { conn }) => {
  try {
    const send = async (body, buttons = [['👑 المطور', '.المطور']]) => {
      let btn = new ButtonV2(conn)
        .setBody(body)
        .setFooter(footerText)
        .setThumbnail(imageUrl)
      for (let [label, cmd] of buttons) btn = btn.addButton(label, cmd)
      await btn.send(m.chat)
    }

    const senderNumber = m.sender.split('@')[0]

    // التحقق من هوية المطور
    if (senderNumber !== DEVELOPER_NUMBER) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      return send(box('👑 غير مصرح لك', [
        '❌ هذا الأمر مخصص للمطور فقط',
        `👤 المطور: +${DEVELOPER_NUMBER}`
      ]))
    }

    // التأكد من وجود قاعدة بيانات المستخدم
    if (!global.db.data.users) global.db.data.users = {}
    if (!global.db.data.users[m.sender]) global.db.data.users[m.sender] = {}

    let user = global.db.data.users[m.sender]

    // منح قيم المطور
    user.money = 999999999999
    user.exp = 999999999
    user.level = 9999
    user.limit = Infinity
    user.premium = true
    user.role = '👑 الـمـطـوّر الـمـطـلـق'

    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } })

    return send(box('👑 تم الترقية', [
      '✅ تم ترقية حسابك إلى مطور مطلق',
      '💰 النقود: غير محدود',
      '🧪 الخبرة: أقصى حد',
      '📈 المستوى: 9999',
      '⭐ الرتبة: 👑 المطور المطلق'
    ]))

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-Qaweni] Error:', e)
  }
}

handler.help = ['قويني']
handler.tags = ['owner']
handler.command = ['قويني', 'لفل_اب', 'powerup', 'ترقية', 'تطوير']
handler.owner = true

export default handler