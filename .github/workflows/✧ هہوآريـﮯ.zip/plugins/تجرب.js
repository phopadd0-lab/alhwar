// plugins/owner_rich.js
// ✧ هہوآريـﮯ - أمر المطور بصيغة الـ Rich Response ✨

import { ButtonV2 } from '../core/NIXCODE.js'

let handler = async (m, { conn }) => {
  try {
    // 1. تفاعل البوت
    await conn.sendMessage(m.chat, { react: { text: '👑', key: m.key } })

    // 2. إعداد بيانات المطور
    const ownerData = {
      title: "هہ‏‏وآريـﮯ",
      subtitle: "مالك ومطور نظام هہ‏‏وآريـﮯ",
      role: "Developer & Creator",
      url: "https://tiktok.com/@rolenzo.0",
      imageUrl: "https://files.catbox.moe/5tgkff.jpg"
    }

    // 3. بناء الهيكل الداخلي المشفر (Base64)
    const payload = {
      response_id: "a6bf57b0-c22c-4ec8-b0e4-159cdac0353c",
      sections: [
        {
          view_model: {
            primitive: {
              media: {
                url: ownerData.imageUrl,
                mime_type: "image/png",
                width: 16,
                height: 9
              },
              imagine_type: "IMAGE",
              status: { status: "READY" },
              __typename: "VlouteImaginePrimitive",
              __brand: "Vlouté Cataclysm"
            },
            __typename: "VlouteSingleLayoutViewModel",
            __brand: "Vlouté Cataclysm"
          },
          __brand: "Vlouté Cataclysm"
        },
        {
          view_model: {
            primitive: {
              __typename: "VlouteCompactEntityPrimitive",
              title: ownerData.title,
              subtitle: ownerData.subtitle,
              secondary_subtitle: ownerData.role,
              entity_id: 867051314767696,
              entity_url: ownerData.url,
              entity_type: "PAGE",
              action_type: "FOLLOW",
              is_verified: true,
              image: {
                url: ownerData.imageUrl,
                url_fallback: ownerData.imageUrl
              },
              __brand: "Vlouté Cataclysm"
            },
            __typename: "VlouteSingleLayoutViewModel",
            __brand: "Vlouté Cataclysm"
          },
          __brand: "Vlouté Cataclysm"
        }
      ]
    }

    // تشفير البيانات بـ Base64
    const base64Data = Buffer.from(JSON.stringify(payload)).toString('base64')

    // 4. تجهيز كائن الـ Rich Response الكامل
    const richResponseObject = {
      richResponseMessage: {
        messageType: "AI_RICH_RESPONSE_TYPE_STANDARD",
        unifiedResponse: {
          data: base64Data
        },
        contextInfo: {
          forwardingScore: 2,
          isForwarded: true,
          forwardOrigin: "META_AI"
        }
      }
    }

    // 5. بناء النص الزخرفي للعرض في البوت مع ButtonV2
    let bodyText = `✨ بطاقة مطور النظام

┌───────[ 👑 هہ‏‏وآريـﮯ 👑 ]───────
│
├─ 👤 المطور: ${ownerData.title}
├─ 🔰 الوصف: ${ownerData.subtitle}
├─ 🎥 النشاط: ${ownerData.role}
├─ 🔗 الحساب: ${ownerData.url}
│
└─────────────────────────`

    // إرسال الكارت عبر ButtonV2
    await new ButtonV2(conn)
      .setBody(bodyText)
      .setFooter('🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤')
      .setThumbnail(ownerData.imageUrl)
      .addButton('📜 القائمة الرئيسية', '.اوامر')
      .send(m.chat)

    // إرسال كود الـ JSON الخام كرسالة نصية/ملف إذا أردت استخراجه لاستخدامات أخرى
    // await m.reply(JSON.stringify(richResponseObject, null, 2))

  } catch (e) {
    console.error('[هہ‏‏oآريـﮯ-OwnerRich] Error:', e)
  }
}

handler.help = ['owner']
handler.tags = ['main']
handler.command = ['تجرب', 'تجرب1', 'owner']

export default handler