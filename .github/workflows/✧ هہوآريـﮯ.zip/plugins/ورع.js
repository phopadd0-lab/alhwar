// plugins/fun-stats.js
// ✧ 2B - YoRHa Unit No.2 Type B - أوامر التسلية 🎭

let handler = async (m, { conn, command, text, usedPrefix }) => {

  const rand = (max) => Math.floor(Math.random() * (max + 1));

  let targetName = '';
  let targetJid = '';
  
  // حالة 1: منشن
  if (m.mentionedJid && m.mentionedJid[0]) {
    targetJid = m.mentionedJid[0];
    try {
      targetName = await conn.getName(targetJid);
    } catch {
      targetName = targetJid.split('@')[0];
    }
  }
  // حالة 2: رد على رسالة
  else if (m.quoted && m.quoted.sender) {
    targetJid = m.quoted.sender;
    try {
      targetName = await conn.getName(targetJid);
    } catch {
      targetName = targetJid.split('@')[0];
    }
  }
  // حالة 3: كتابة اسم/رقم مباشر
  else if (text && text.trim()) {
    const input = text.trim();
    if (/^\d+$/.test(input)) {
      targetJid = input + '@s.whatsapp.net';
      try { targetName = await conn.getName(targetJid); } catch { targetName = input; }
    } else {
      targetName = input;
    }
  }
  // حالة 4: لا يوجد هدف
  else {
    return m.reply(`> ❄️ *2B: "أمر ${command}"*\n> \n> 🎭 قم بمنشن الشخص أو كتابة اسمه أو رد على رسالته\n> 📌 *مثال:* ${usedPrefix + command} @user\n> 📌 *مثال:* ${usedPrefix + command} محمد`);
  }

  if (!targetName) targetName = 'المستخدم';

  const displayText = targetName;
  const randomPercent = rand(100);

  let reply = '';
  let emoji = '';

  switch (command) {
    case 'ورع':
      emoji = '🧒';
      reply = `> ❄️ *2B: "نسبة الورع"*\n> \n> 👤 *الاسم:* ${displayText}\n> 📊 *النسبة:* ${randomPercent}%\n> 💬 ${randomPercent > 70 ? 'يا سلام ورع بمعنى الكلمة 😂' : 'لسه صغير واعد 🧒'}`;
      break;
      
    case 'اهبل':
      emoji = '🤪';
      reply = `> ❄️ *2B: "نسبة الهبل"*\n> \n> 👤 *الاسم:* ${displayText}\n> 📊 *النسبة:* ${randomPercent}%\n> 💬 ${randomPercent > 70 ? 'اهبل بطل خلي بالك منه 😂' : 'لسه شاطر وواعي 🧠'}`;
      break;
      
    case 'خروف':
      emoji = '🐑';
      reply = `> ❄️ *2B: "نسبة الخرفنة"*\n> \n> 👤 *الاسم:* ${displayText}\n> 📊 *النسبة:* ${randomPercent}%\n> 💬 ${randomPercent > 70 ? 'خروف والله يابو حمل 🐑' : 'لسه مش خروف كفاية 😅'}`;
      break;
      
    case 'جميل':
      emoji = '😍';
      reply = `> ❄️ *2B: "نسبة الجمال"*\n> \n> 👤 *الاسم:* ${displayText}\n> 📊 *النسبة:* ${randomPercent}%\n> 💬 ${randomPercent > 70 ? 'فديت القمر 🌙' : 'جمالك جايب آخره ✨'}`;
      break;
      
    case 'ذكاء':
      emoji = '🧠';
      reply = `> ❄️ *2B: "نسبة الذكاء"*\n> \n> 👤 *الاسم:* ${displayText}\n> 📊 *النسبة:* ${randomPercent}%\n> 💬 ${randomPercent > 70 ? 'عبقري بمعنى الكلمة 🧠' : 'ذكائك في ازدياد 📈'}`;
      break;
      
    case 'غباء':
      emoji = '🤦';
      reply = `> ❄️ *2B: "نسبة الغباء"*\n> \n> 👤 *الاسم:* ${displayText}\n> 📊 *النسبة:* ${randomPercent}%\n> 💬 ${randomPercent > 70 ? 'غبي بطل خلي بالك 🤦' : 'لسه فيه أمل 🤞'}`;
      break;
      
    default:
      reply = `> ❄️ *2B: "خطأ"*\n> \n> 🔮 الأمر ${command} غير معروف`;
  }

  await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
  return m.reply(reply);
};

handler.help = ['ورع', 'اهبل', 'خروف', 'جميل', 'ذكاء', 'غباء'];
handler.tags = ['entertainment'];
handler.command = /^(ورع|اهبل|خروف|جميل|ذكاء|غباء)$/i;

export default handler;