// plugins/رابط_الجروب.js
// ✧ 2B - YoRHa Unit No.2 Type B - رابط المجموعة 🔗

const LINK_IMAGE = 'https://file.garden/aauvg01sjleV_ic1/79c0c2e640389275839611a46b4f3ec2.jpg'

const handler = async (m, { conn, isAdmin, isBotAdmin }) => {
  try {
    if (!m.isGroup) return global.dfail('group', m, conn)
    if (!isAdmin) return global.dfail('admin', m, conn)
    if (!isBotAdmin) return global.dfail('botAdmin', m, conn)

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    let inviteCode = await conn.groupInviteCode(m.chat)
    let inviteLink = 'https://chat.whatsapp.com/' + inviteCode

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
    
    await conn.sendMessage(m.chat, {
      image: { url: LINK_IMAGE },
      caption: `📌 *تفضل لينك الشات*\n\n🔗 ${inviteLink}\n\n⚡ *2B - YoRHa Unit*`
    }, { quoted: m })

  } catch (e) {
    console.error('[2B-رابط] خطأ:', e)
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    m.reply('❌ فشل جلب الرابط - تأكد من صلاحيات البوت')
  }
}

handler.command = /^(لينك|رابط_الجروب|invite|getlink|رابط|الرابط)$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler