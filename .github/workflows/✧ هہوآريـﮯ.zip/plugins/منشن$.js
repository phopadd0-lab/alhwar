// plugins/tagall.js
let handler = async (m, { conn, isAdmin, isOwner, isROwner }) => {
    if (!m.isGroup) return;
    if (!isAdmin && !isOwner && !isROwner) {
        global.dfail('admin', m, conn);
        return;
    }

    let groupData = conn.chats?.[m.chat];
    if (!groupData?.metadata?.participants) return m.reply('لا يمكن الوصول لبيانات المجموعة');

    let participants = groupData.metadata.participants;
    let mentions = participants.map(p => p.id);
    let tags = participants.map(p => '@' + p.id.split('@')[0]).join('\n');

    let text = `*👥 منشن جميع الأعضاء*\n\n${tags}`;
    let imageUrl = 'https://file.garden/aauvg01sjleV_ic1/37c9471233c8d5a000932d421781d274.jpg';

    await conn.sendMessage(m.chat, { image: { url: imageUrl }, caption: text, mentions });
};

handler.command = /^منشن$/i;
handler.group = true;
handler.admin = true;

export default handler;