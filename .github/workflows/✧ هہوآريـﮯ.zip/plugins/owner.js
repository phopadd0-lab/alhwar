// plugins/owner.js
// ✧ هہ‏‏وآريـﮯ - المطور

import { theme } from '../core/theme.js'

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: 'https://file.garden/aauvg01sjleV_ic1/pro.opus' },
        mimetype: 'audio/mp4',
        ptt: true 
      },
      { quoted: m }
    );
    await new Promise(resolve => setTimeout(resolve, 1000));
  } catch (e) {}

  let vcard = `BEGIN:VCARD
VERSION:3.0
FN: هہ‏‏وآريـﮯ 
ORG:YoRHa
TITLE:هہ‏‏وآريـﮯ - YoRHa Unit
EMAIL;type=INTERNET:go588288@gmail.com
TEL;type=CELL;waid=201229982764:+201229982764
ADR;type=WORK:;;Bunker;YoRHa;;
URL;type=WORK:https://www.instagram.com/go24.q?igsh=MWdoYWtjZWNnMGhncQ==
هہ‏‏وآريـﮯ
END:VCARD`

  let qkontak = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast"
    },
    message: {
      contactMessage: {
        displayName: " هہ‏‏وآريـﮯ ",
        vcard
      }
    }
  }

  await conn.sendMessage(
    m.chat,
    {
      contacts: {
        displayName: 'هہ‏‏وآريـﮯ ',
        contacts: [{ vcard }]
      }
    },
    { quoted: qkontak }
  )
}

handler.help = ['owner', 'creator']
handler.tags = ['main']
handler.command = /^(owner|creator|المطورين|المطور|مطور|مطورك|مطوري|creador)$/i

export default handler