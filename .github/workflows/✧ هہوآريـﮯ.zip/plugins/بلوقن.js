// plugins/بلوقن.js
// ✧ هہ‏‏‏‏وآريـﮯ - إدارة البلوقنات 📦

import { ButtonV2 } from '../core/NIXCODE.js'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { downloadContentFromMessage, generateWAMessageFromContent, generateMessageIDV2 } from '@whiskeysockets/baileys'

const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
const footerText = '🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤'

const __filename = fileURLToPath(import.meta.url)
const pluginsDir = path.dirname(__filename)
const currentFile = path.basename(__filename)

// بناء صندوق منسق
function box(title, lines = []) {
  let out = `┌──────[ ${title} ]──────\n│\n`
  for (let l of lines) out += `├─ ${l}\n`
  out += `│\n└─────────────────────────`
  return out
}

let handler = async (m, { conn, args, usedPrefix }) => {
  try {
    const react = async (e) => {
      try { await conn.sendMessage(m.chat, { react: { text: e, key: m.key } }) } catch {}
    }

    const send = async (body, buttons = []) => {
      let btn = new ButtonV2(conn)
        .setBody(body)
        .setFooter(footerText)
        .setThumbnail(imageUrl)
      // ButtonV2 لازم يكون فيه زر واحد على الأقل
      if (!buttons.length) buttons = [['📦 القائمة', `${usedPrefix}بلوقن`]]
      for (let [label, cmd] of buttons) btn = btn.addButton(label, cmd)
      await btn.send(m.chat)
    }

    const getPlugins = () => fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js') && f !== currentFile)

    const findPlugin = (name) => {
      let searchName = name.replace(/\.js$/i, '').trim().toLowerCase().replace(/\s+/g, '-')
      const allFiles = getPlugins()
      let found = allFiles.find(f => f.toLowerCase() === searchName + '.js')
      if (found) return found
      found = allFiles.find(f => f.replace(/-/g, '_').toLowerCase() === searchName.replace(/-/g, '_') + '.js')
      if (found) return found
      found = allFiles.find(f => f.toLowerCase().includes(searchName))
      return found || null
    }

    const action = (args[0] || '').toLowerCase()

    // ⭐ عرض الكود
    if (/^(عرض|show|get)$/i.test(action)) {
      const nameArg = args.slice(1).join(' ').trim()
      if (!nameArg) {
        return send(box('📄 عرض بلوقن', [`📌 الاستخدام: ${usedPrefix}بلوقن عرض <اسم>`]))
      }

      const foundFile = findPlugin(nameArg)
      if (!foundFile) {
        await react('❌')
        return send(box('❌ خطأ', [`الملف "${nameArg}" غير موجود`]))
      }

      const code = fs.readFileSync(path.join(pluginsDir, foundFile), 'utf-8')
      const fileSize = (code.length / 1024).toFixed(2)
      const totalLines = code.split('\n').length

      await react('📄')

      const botMeta = {
        isForwarded: true,
        forwardingScore: 1,
        forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
        forwardOrigin: 4
      }

      // تقسيم الكود لكتل حسب النوع
      const codeBlocks = []
      let currentBlock = ''
      let blockType = 1

      for (const line of code.split('\n')) {
        if (line.startsWith('//') || line.startsWith('/*') || line.startsWith('*')) {
          if (currentBlock) { codeBlocks.push({ highlightType: blockType, codeContent: currentBlock }); currentBlock = '' }
          blockType = 3
        } else if (line.includes('handler.') || line.includes('export')) {
          if (currentBlock) { codeBlocks.push({ highlightType: blockType, codeContent: currentBlock }); currentBlock = '' }
          blockType = 2
        } else if (line.trim() === '' || /^(import|const|let)/.test(line.trim())) {
          if (currentBlock && blockType !== 2 && blockType !== 3) blockType = 1
        } else {
          if (currentBlock && blockType !== 2 && blockType !== 3) blockType = 4
        }
        currentBlock += line + '\n'
      }
      if (currentBlock) codeBlocks.push({ highlightType: blockType, codeContent: currentBlock })

      const richMessage = {
        richResponseMessage: {
          messageType: 1,
          submessages: [
            { messageType: 2, messageText: `\n📄 *${foundFile}*\n📦 ${fileSize} KB | 📝 ${totalLines} سطر\n⚡ ${global.watermark || '✧ هہ‏‏وآريـﮯ ✧'}\n` },
            { messageType: 2, messageText: `\n💻 *الكود:*\n` },
            { messageType: 5, codeMetadata: { codeLanguage: 'javascript', codeBlocks } }
          ],
          contextInfo: botMeta
        }
      }

      try {
        const msg = await generateWAMessageFromContent(m.chat, { botForwardedMessage: { message: richMessage } }, {
          senderId: conn.user.id,
          userJid: conn.user.id,
          messageId: generateMessageIDV2(conn.user.id)
        })
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
      } catch (err) {
        console.error('[هہ‏‏وآريـﮯ-Plugin] Rich message failed:', err)
        await conn.sendMessage(m.chat, {
          text: `📄 *${foundFile}*\n📦 ${fileSize} KB | 📝 ${totalLines} سطر\n\n\`\`\`javascript\n${code}\n\`\`\``
        }, { quoted: m })
      }
      return
    }

    // ⭐ لست
    if (/^(لست|list)$/i.test(action)) {
      const plugins = getPlugins()
      await react('📦')
      if (!plugins.length) return send(box('📂 لا يوجد', ['لا توجد بلوقنات']))

      const lines = plugins.map((f, i) => `⚡ ${i + 1}. ${f.replace('.js', '')}`)
      lines.push(`📊 المجموع: ${plugins.length} بلوقن`)
      return send(box('📦 قائمة البلوقنات', lines))
    }

    // ⭐ حذف
    if (/^(حذف|delete|del|remove)$/i.test(action)) {
      const nameArg = args.slice(1).join(' ').trim()
      if (!nameArg) {
        return send(box('🗑️ حذف بلوقن', [`📌 الاستخدام: ${usedPrefix}بلوقن حذف <اسم>`]))
      }

      const foundFile = findPlugin(nameArg)
      if (!foundFile) {
        await react('❌')
        return send(box('❌ خطأ', [`الملف "${nameArg}" غير موجود`]))
      }

      const filePath = path.join(pluginsDir, foundFile)
      const code = fs.readFileSync(filePath, 'utf-8')
      const fileSize = (code.length / 1024).toFixed(2)
      const lineCount = code.split('\n').length

      fs.unlinkSync(filePath)
      if (global.plugins?.[foundFile]) delete global.plugins[foundFile]

      await react('🗑️')
      return send(box('🗑️ تم الحذف', [
        `📄 الملف: ${foundFile}`,
        `📦 الحجم: ${fileSize} KB`,
        `📝 الأسطر: ${lineCount} سطر`
      ]), [['📋 القائمة', `${usedPrefix}بلوقن لست`]])
    }

    // ⭐ إضافة
    if (/^(اضف|اضافه|اضافة|add)$/i.test(action)) {
      const quoted = m.quoted
      if (!quoted) {
        await react('❌')
        return send(box('❌ خطأ', ['رد على كود أو ملف البلوقن']))
      }

      let code = ''
      let fileName = ''

      const docMsg = quoted.message?.documentMessage || quoted.message?.documentWithCaptionMessage?.message?.documentMessage || null

      if (docMsg) {
        let buffer
        try { buffer = await quoted.download() } catch {
          try {
            const stream = await downloadContentFromMessage(docMsg, 'document')
            const chunks = []
            for await (const c of stream) chunks.push(c)
            buffer = Buffer.concat(chunks)
          } catch (e) {
            await react('❌')
            return send(box('❌ خطأ', [`فشل تحميل الملف: ${e.message}`]))
          }
        }
        const baseName = (docMsg.fileName || `plugin_${Date.now()}`).replace(/\.js$/i, '')
        fileName = `${baseName}.js`
        code = buffer.toString('utf-8')
      } else {
        code = quoted.text || quoted.body || ''
        if (!code.trim()) {
          await react('❌')
          return send(box('❌ خطأ', ['الرسالة مفيهاش كود']))
        }

        // استخراج اسم الملف من الكود
        let extractedName = null

        const cmdMatch1 = code.match(/handler\.command\s*=\s*\/\^\(?([^)\/|\\s]+)/)
        if (cmdMatch1) extractedName = cmdMatch1[1].trim()

        if (!extractedName) {
          const cmdMatch2 = code.match(/handler\.command\s*=\s*\[['"`]([^'"`]+)['"`]/)
          if (cmdMatch2) extractedName = cmdMatch2[1].trim()
        }

        if (!extractedName) {
          const fileMatch = code.match(/\/\/\s*(?:plugins|commands)\/([a-zA-Z0-9_\u0600-\u06FF-]+)\.js/)
          if (fileMatch) extractedName = fileMatch[1].trim()
        }

        if (!extractedName) extractedName = `plugin_${Date.now().toString(36)}`

        fileName = `${extractedName}.js`
      }

      const savePath = path.join(pluginsDir, fileName)
      const isEdit = fs.existsSync(savePath)
      fs.writeFileSync(savePath, code, 'utf-8')

      const fileSize = (code.length / 1024).toFixed(2)
      const lineCount = code.split('\n').length

      await react('✅')
      return send(box(isEdit ? '✏️ تم التعديل' : '✅ تمت الإضافة', [
        `📄 الملف: ${fileName}`,
        `📦 الحجم: ${fileSize} KB`,
        `📝 الأسطر: ${lineCount} سطر`
      ]), [['📋 القائمة', `${usedPrefix}بلوقن لست`]])
    }

    // القائمة الافتراضية
    await react('📦')
    return send(box('📦 إدارة البلوقنات', [
      `📋 ${usedPrefix}بلوقن لست ← قائمة كل البلوقنات`,
      `📄 ${usedPrefix}بلوقن عرض <اسم> ← عرض الكود`,
      `➕ ${usedPrefix}بلوقن اضف ← إضافة بلوقن جديد (بالرد)`,
      `🗑️ ${usedPrefix}بلوقن حذف <اسم> ← حذف بلوقن`
    ]), [['📋 لست', `${usedPrefix}بلوقن لست`]])

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-Plugin] Error:', e)
  }
}

handler.help = ['بلوقن']
handler.tags = ['owner']
handler.command = ['بلوقن', 'plugin', 'plugins']
handler.owner = true

export default handler