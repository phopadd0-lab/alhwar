// plugins/apk.js
// ✧ هہ‏‏‏‏وآريـﮯ - تحميل تطبيقات APK 📱

import { ButtonV2 } from '../core/NIXCODE.js'
import fetch from 'node-fetch'
import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
const footerText = '🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤'

// بناء صندوق منسق
function box(title, lines = []) {
  let out = `┌──────[ ${title} ]──────\n│\n`
  for (let l of lines) out += `├─ ${l}\n`
  out += `│\n└─────────────────────────`
  return out
}

let handler = async (m, { conn, text, usedPrefix }) => {
  try {
    // إرسال رد بالشكل الموحد (ButtonV2 لازم فيه زر واحد على الأقل)
    const send = async (body, buttons, thumb = imageUrl) => {
      if (!buttons?.length) buttons = [['📱 تحميل تطبيق', `${usedPrefix}apk`]]
      let btn = new ButtonV2(conn)
        .setBody(body)
        .setFooter(footerText)
        .setThumbnail(thumb)
      for (let [label, cmd] of buttons) btn = btn.addButton(label, cmd)
      await btn.send(m.chat)
    }

    // ⭐ رسالة المساعدة
    if (!text) {
      return send(box('📱 تحميل تطبيقات APK', [
        '⚔️ تحميل تطبيقات APK مع ملفات OBB',
        `⚡ الاستخدام: ${usedPrefix}apk <اسم التطبيق>`,
        `📌 مثال: ${usedPrefix}apk free fire`
      ]), [['📌 مثال', `${usedPrefix}apk free fire`]])
    }

    // ⭐ اسم حزمة (com.xxx) = تم اختيارها من القائمة
    if (/^com\./i.test(text.trim())) {
      await conn.sendMessage(m.chat, { react: { text: '⏬', key: m.key } })

      try {
        const info = await getAppInfo(text.trim())
        const res = await downloadApp(text.trim())

        if (Number(res.size) > 2000000000) {
          return send(box('❌ خطأ', ['حجم ملف APK كبير جداً', 'الحد الأقصى: 2GB']))
        }

        // معلومات التطبيق
        await send(box('📱 معلومات التطبيق', [
          `📱 الاسم: ${info.name}`,
          `📦 الحزمة: ${info.packageN}`,
          '⏳ جاري تحميل الملف...'
        ]), null, info.icon)

        // ملف APK
        await conn.sendMessage(m.chat, {
          document: { url: res.download },
          mimetype: res.mimetype,
          fileName: res.fileName
        }, { quoted: m })

        // ملف OBB لو موجود
        if (info.obb) {
          await send(box('📦 ملف OBB', [`⏳ جاري تحميل ملف OBB لـ ${info.name}...`]))

          const obbRes = await fetch(info.obb_link, { method: 'HEAD' })
          const obbMimetype = obbRes.headers.get('content-type')
          const obbFileName = decodeURIComponent(info.obb_link.split('/').pop().split('?')[0])

          await conn.sendMessage(m.chat, {
            document: { url: info.obb_link },
            mimetype: obbMimetype,
            fileName: obbFileName
          }, { quoted: m })
        }

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

      } catch (e) {
        console.error('[هہ‏‏وآريـﮯ-APK] Download error:', e)
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        return send(box('❌ خطأ', ['فشل في تحميل APK']))
      }
      return
    }

    // ⭐ وضع البحث
    await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } })

    const apps = await searchApps(text)
    if (!apps.length) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      return send(box('🔍 بحث', ['لم يتم العثور على أي تطبيقات']))
    }

    // قائمة النتائج (قائمة اختيار أصلية عشان فيه لحد 10 نتائج)
    const sections = [{
      title: '📱 نتائج البحث',
      rows: apps.map(app => ({
        title: app.name,
        description: app.package,
        id: `${usedPrefix}apk ${app.package}`
      }))
    }]

    const imageRes = await fetch(imageUrl)
    const imageBuffer = Buffer.from(await imageRes.arrayBuffer())
    const media = await prepareWAMessageMedia({ image: imageBuffer }, { upload: conn.waUploadToServer })

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject({
      body: {
        text: box('🔍 بحث عن', [
          `⚡ البحث: ${text}`,
          '📱 اختر تطبيق لتحميله'
        ])
      },
      footer: { text: footerText },
      header: {
        hasMediaAttachment: true,
        subtitle: '📲 متجر APK ⚔️',
        imageMessage: media.imageMessage
      },
      nativeFlowMessage: {
        buttons: [{
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: '📲 اختر تطبيق APK',
            sections
          })
        }],
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            list_title: '📱 تطبيقات APK',
            button_title: '⚔️ اضغط لعرض النتائج'
          }
        })
      }
    })

    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, {
      userJid: conn.user.jid,
      quoted: fkontak
    })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-APK] Error:', e)
    try {
      await new ButtonV2(conn)
        .setBody(box('❌ خطأ', ['حدث خطأ أثناء البحث']))
        .setFooter(footerText)
        .setThumbnail(imageUrl)
        .addButton('📱 تحميل تطبيق', `${usedPrefix}apk`)
        .send(m.chat)
    } catch {}
  }
}

// ========== دوال مساعدة ==========
async function searchApps(query) {
  const res = await fetch('http://ws75.aptoide.com/api/7/apps/search?query=' + encodeURIComponent(query) + '&limit=10')
  const json = await res.json()
  return json.datalist.list.map(app => ({
    name: app.name,
    package: app.package
  }))
}

async function getAppInfo(packageName) {
  const res = await fetch('http://ws75.aptoide.com/api/7/apps/search?query=' + encodeURIComponent(packageName) + '&limit=1')
  const json = await res.json()
  const app = json.datalist.list[0]

  if (!app) throw new Error('لم يتم العثور على التطبيق')

  let obb_link, obb = false
  try {
    obb_link = app.obb.main.path
    obb = true
  } catch {
    obb_link = null
  }

  return {
    obb,
    obb_link,
    name: app.name,
    icon: app.icon,
    packageN: app.package
  }
}

async function downloadApp(packageName) {
  const res = await fetch('http://ws75.aptoide.com/api/7/apps/search?query=' + encodeURIComponent(packageName) + '&limit=1')
  const json = await res.json()
  const app = json.datalist.list[0]

  const download = app.file.path
  const fileName = app.package + '.apk'
  const head = await fetch(download, { method: 'HEAD' })
  const size = head.headers.get('content-length')
  const mimetype = head.headers.get('content-type')

  return { fileName, mimetype, download, size }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://file.garden/aauvg01sjleV_ic1/a2075690da240b4d4af5e9affed48bbe.jpg')
    const thumb2 = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '✧ هہ‏‏وآريـﮯ ✧', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    }
  } catch {
    return undefined
  }
}

handler.help = ['apk']
handler.tags = ['downloader']
handler.command = ['apk']
handler.premium = false
handler.register = false

export default handler