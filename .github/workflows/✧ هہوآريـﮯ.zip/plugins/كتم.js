// plugins/mute.js
// ✧ Raiden Shogun ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ - كتم أو فك كتم عضو 🔇

import fetch from 'node-fetch';

let handler = async (m, { conn, command, isAdmin }) => {

    if (!m.isGroup) return;
    
    if (!isAdmin) {
        return m.reply('> ❄️ *2B: "صلاحيات غير كافية"*\n> \n> ⚠️ فقط المشرفين يمكنهم تنفيذ هذا الأمر');
    }

    let targetJid = null;
    
    if (m.mentionedJid && m.mentionedJid[0]) {
        targetJid = m.mentionedJid[0];
    } else if (m.quoted && m.quoted.sender) {
        targetJid = m.quoted.sender;
    } else {
        await conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
        return m.reply(`> ❄️ *2B: "أمر الكتم"*\n> \n> ⚠️ قم بالرد على رسالة العضو أو منشنه`);
    }

    const targetKey = targetJid;
    const botLid = conn.user?.lid || '';
    const botJid = conn.user?.jid || conn.user?.id || '';
    if (targetKey === botLid || targetKey === botJid) {
        return m.reply('> ❄️ *2B: "ممنوع"*\n> \n> ❌ لا يمكنك تنفيذ الأمر على البوت');
    }

    if (!global.db.data.users) global.db.data.users = {};
    if (!global.db.data.users[targetKey]) {
        global.db.data.users[targetKey] = { muto: {} };
    }

    let userData = global.db.data.users[targetKey];
    if (!userData.muto || typeof userData.muto !== 'object') {
        userData.muto = {};
    }

    let targetName = targetKey.split('@')[0].replace('lid_', '');
    try {
        const name = await conn.getName(targetKey);
        if (name) targetName = name;
    } catch(e) {}

    const fkontak = {
        key: { participants: '0@s.whatsapp.net', fromMe: false, id: 'Halo' },
        message: {
            locationMessage: {
                name: command === 'كتم' ? 'Mute System 🔇' : 'Unmute System 🔊',
                jpegThumbnail: await (await fetch(
                    command === 'كتم'
                        ? 'https://telegra.ph/file/f8324d9798fa2ed2317bc.png'
                        : 'https://telegra.ph/file/aea704d0b242b8c41bf15.png'
                )).buffer()
            }
        },
        participant: '0@s.whatsapp.net'
    };

    if (command === "كتم") {
        if (userData.muto[m.chat] === true) {
            return m.reply('> ❄️ *2B: "تنبيه"*\n> \n> ⚠️ هذا العضو مكتوم بالفعل في هذا الجروب');
        }
        
        userData.muto[m.chat] = true;
        
        if (global.db.writeData) {
            await global.db.writeData('users', targetKey, userData).catch(() => {});
        }
        
        await conn.sendMessage(m.chat, { react: { text: '🔇', key: m.key } });
        await conn.reply(m.chat, `> ❄️ *2B: "تم كتم العضو"*\n> \n> 👤 *العضو:* ${targetName}\n> 🔇 تم كتم العضو في هذا الجروب`, fkontak);
    }

    else if (command === "فك_الكتم") {
        if (!userData.muto[m.chat]) {
            return m.reply('> ❄️ *2B: "تنبيه"*\n> \n> ⚠️ هذا العضو غير مكتوم في هذا الجروب');
        }
        
        delete userData.muto[m.chat];
        
        if (global.db.writeData) {
            await global.db.writeData('users', targetKey, userData).catch(() => {});
        }
        
        await conn.sendMessage(m.chat, { react: { text: '🔊', key: m.key } });
        await conn.reply(m.chat, `> ❄️ *2B: "تم فك كتم العضو"*\n> \n> 👤 *العضو:* ${targetName}\n> 🔊 تم فك كتمه في هذا الجروب`, fkontak);
    }
};

// ✅ حذف رسايل المكتومين - حتى الأدمن
handler.all = async function (m) {
    if (!m.isGroup || !global.db.data.users) return;
    
    const userData = global.db.data.users[m.sender];
    if (!userData || !userData.muto || !userData.muto[m.chat]) return;

    // ✅ حذف الرسالة بدون تخطي الأدمن
    await this.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.sender
        }
    }).catch(() => {});
};

handler.help = ['كتم', 'فك_الكتم'];
handler.command = /^(كتم|فك_الكتم)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;