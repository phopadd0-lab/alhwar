// plugins/sticker.js
// ♡ Raiden Shogun - Sticker Maker 🎨

import { exec } from 'child_process'
import { promisify } from 'util'
import { writeFileSync, unlinkSync, existsSync, readFileSync } from 'fs'
import { join } from 'path'
import { tmpdir } from 'os'
import sharp from 'sharp'
import webp from 'node-webpmux'
import crypto from 'crypto'
import { generateWAMessage } from '@whiskeysockets/baileys'

const execAsync = promisify(exec)

async function getVideoFPS(inputPath) {
  try {
    const { stdout } = await execAsync(
      `ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate -of default=noprint_wrappers=1:nokey=1 "${inputPath}"`,
      { timeout: 10000 }
    )
    let fps = stdout.trim()
    if (fps.includes('/')) {
      let [num, den] = fps.split('/').map(Number)
      fps = Math.round(num / den)
    }
    return Math.min(Math.max(parseInt(fps) || 15, 8), 30)
  } catch {
    return 15
  }
}

async function getVideoDuration(inputPath) {
  try {
    const { stdout } = await execAsync(
      `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${inputPath}"`,
      { timeout: 10000 }
    )
    return parseFloat(stdout.trim()) || 7
  } catch {
    return 7
  }
}

async function addStickerMetadata(webpBuffer, packName = 'Raiden Shogun', authorName = '❦ PROTOYPE') {
  try {
    const img = new webp.Image()
    await img.load(webpBuffer)

    const json = {
      'sticker-pack-id': crypto.randomBytes(32).toString('hex'),
      'sticker-pack-name': packName,
      'sticker-pack-publisher': authorName,
      'emojis': ['⚡', '❦']
    }

    const exifAttr = Buffer.from([
      0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00, 0x00, 0x00
    ])

    const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8')
    const exif = Buffer.concat([exifAttr, jsonBuffer])
    exif.writeUIntLE(jsonBuffer.length, 14, 4)
    img.exif = exif

    return await img.save(null)
  } catch {
    return webpBuffer
  }
}

async function processImageToSticker(media) {
  let webp = await sharp(media)
    .resize(512, 512, { fit: 'inside', withoutEnlargement: true })
    .webp({ quality: 90, lossless: false })
    .toBuffer()

  return await addStickerMetadata(webp, 'Raiden Shogun', '❦ PROTOYPE')
}

async function processVideoToSticker(media) {
  let inputPath = join(tmpdir(), `sticker_in_${Date.now()}.mp4`)
  let outputPath = join(tmpdir(), `sticker_out_${Date.now()}.webp`)

  writeFileSync(inputPath, media)

  let originalFPS = await getVideoFPS(inputPath)
  let duration = await getVideoDuration(inputPath)
  let maxDuration = Math.min(duration, 7)

  let cmd = `ffmpeg -i "${inputPath}" -vf "fps=${originalFPS},scale=512:512:flags=lanczos" -c:v libwebp -lossless 0 -compression_level 4 -q:v 50 -loop 0 -preset default -an -t ${maxDuration} "${outputPath}" -y`

  await execAsync(cmd, { timeout: 60000 })

  if (!existsSync(outputPath)) throw new Error('فشل التحويل')

  let stickerBuffer = readFileSync(outputPath)

  if (stickerBuffer.length > 1024 * 1024) {
    let smallerPath = join(tmpdir(), `sticker_small_${Date.now()}.webp`)
    let cmd2 = `ffmpeg -i "${inputPath}" -vf "fps=${Math.min(originalFPS, 10)},scale=256:256:flags=lanczos" -c:v libwebp -lossless 0 -compression_level 6 -q:v 70 -loop 0 -preset default -an -t ${maxDuration} "${smallerPath}" -y`
    await execAsync(cmd2, { timeout: 60000 })
    
    if (existsSync(smallerPath)) {
      stickerBuffer = readFileSync(smallerPath)
      try { unlinkSync(smallerPath) } catch {}
    }
  }

  stickerBuffer = await addStickerMetadata(stickerBuffer, 'Raiden Shogun', '❦ PROTOYPE')

  try { unlinkSync(inputPath) } catch {}
  try { unlinkSync(outputPath) } catch {}

  return stickerBuffer
}

// ✅ دالة إرسال الاستيكر مع القناة
async function sendStickerWithChannel(conn, chat, stickerBuffer, quoted) {
  const msg = await generateWAMessage(chat, {
    sticker: stickerBuffer,
    mimetype: 'image/webp',
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363411230730060@newsletter',
        newsletterName: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽',
        serverMessageId: '-1'
      }
    }
  }, { userJid: conn.user.jid, upload: conn.waUploadToServer })

  if (msg.message?.stickerMessage) {
    msg.message.stickerMessage.annotations = [{
      polygonVertices: [
        { x: 60.72, y: -36.40 },
        { x: -16.71, y: 49.26 },
        { x: -56.59, y: 37.86 },
        { x: 20.84, y: -47.80 }
      ],
      newsletter: {
        newsletterJid: '120363411230730060@newsletter',
        newsletterName: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽',
        contentType: 'UPDATE',
        accessibilityText: '⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽'
      }
    }]
  }

  await conn.relayMessage(chat, msg.message, { messageId: msg.key.id })
}

let handler = async (m, { conn }) => {
  try {
    const ctx = m?.message?.extendedTextMessage?.contextInfo || {}
    const quotedMsg = ctx.quotedMessage || {}
    const quotedType = Object.keys(quotedMsg)[0] || ''

    // ⚡ لو رد على ألبوم
    if (quotedType === 'albumMessage') {
      await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

      const stanzaId = ctx.stanzaId || ''
      const msgs = conn.chats?.[m.chat]?.messages || {}
      const entries = Object.entries(msgs)

      let albumIndex = -1
      for (let i = 0; i < entries.length; i++) {
        if (entries[i][0] === stanzaId || entries[i][1]?.key?.id === stanzaId) {
          albumIndex = i
          break
        }
      }

      if (albumIndex === -1) {
        return m.reply('❌ *مش لاقي الألبوم*')
      }

      const expectedImages = entries[albumIndex][1]?.message?.albumMessage?.expectedImageCount || 0
      const expectedVideos = entries[albumIndex][1]?.message?.albumMessage?.expectedVideoCount || 0
      const totalExpected = expectedImages + expectedVideos

      const mediaMsgs = entries.slice(albumIndex + 1, albumIndex + 1 + totalExpected)
      const sharpMod = (await import('sharp')).default

      let sentCount = 0

      for (const [id, msg] of mediaMsgs) {
        try {
          const type = Object.keys(msg?.message || {})[0] || ''
          const mediaContent = msg?.message?.[type] || {}

          const mediaBuffer = await conn.downloadM(mediaContent, type.replace('Message', ''))

          if (!mediaBuffer || !mediaBuffer.length) continue

          let stickerBuffer

          if (type === 'videoMessage') {
            stickerBuffer = await processVideoToSticker(mediaBuffer)
          } else {
            stickerBuffer = await sharpMod(mediaBuffer)
              .resize(512, 512, { fit: 'inside', withoutEnlargement: true })
              .webp({ quality: 90, lossless: false })
              .toBuffer()

            stickerBuffer = await addStickerMetadata(stickerBuffer)
          }

          await sendStickerWithChannel(conn, m.chat, stickerBuffer, m)
          sentCount++
          await new Promise(resolve => setTimeout(resolve, 1000))
        } catch (e) {
          console.error('❌ فشل:', e.message)
        }
      }

      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
      return m.reply(`✅ *تم تحويل ${sentCount} من ${totalExpected} ملصق*`)
    }

    // ⚡ لو صورة أو فيديو واحد
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''

    if (!mime || (!mime.includes('image') && !mime.includes('video'))) {
      return m.reply('⚡ *الرجاء الرد على صورة أو فيديو أو ألبوم*')
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    let media = await q.download()

    let stickerBuffer

    if (mime.includes('image')) {
      stickerBuffer = await processImageToSticker(media)
    } else {
      stickerBuffer = await processVideoToSticker(media)
    }

    await sendStickerWithChannel(conn, m.chat, stickerBuffer, m)
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (e) {
    console.error(e)
    await m.reply('❌ *فشل التحويل*')
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  }
}

handler.command = ['ستيكر', 'sticker', 'ملصق']
handler.help = ['ستيكر']
handler.tags = ['sticker']

export default handler