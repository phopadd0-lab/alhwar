// plugins/hidetag.js
// ✧ Raiden Shogun ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ - منشن مخفي 🔔

import { generateWAMessageFromContent } from '@whiskeysockets/baileys'

let handler = async (m, { conn, text, isAdmin }) => {

    if (!m.isGroup) return
    
    if (!isAdmin) {
        return m.reply('> ❄️ *2B: "صلاحيات غير كافية"*\n> \n> ⚠️ فقط المشرفين يمكنهم تنفيذ هذا الأمر')
    }

    const meta = await conn.groupMetadata(m.chat)
    const users = meta.participants.map(u => u.id)

    let teks = text ? text : (m.quoted ? m.quoted.text : '')

    if (!teks) {
        return m.reply('✳️ *اكتب النص بعد الأمر أو رد على رسالة*\n\n📌 مثال: .مخفي رسالة مهمة\n📌 أو: رد على رسالة واكتب .مخفي')
    }

    // ✅ اقتباس وهمي على شكل GIF
    const fakegif = {
        key: { participant: '0@s.whatsapp.net', remoteJid: m.chat },
        message: {
            videoMessage: {
                title: '🔔 *تنبيه للجميع*',
                seconds: 99999,
                gifPlayback: true,
                caption: '🔔 *تنبيه للجميع*'
            }
        }
    }

    const msg = generateWAMessageFromContent(
        m.chat,
        {
            extendedTextMessage: {
                text: '🔔 *' + teks + '*',
                contextInfo: {
                    mentionedJid: users
                }
            }
        },
        {
            quoted: m.quoted ? m.quoted : fakegif,
            userJid: conn.user.id
        }
    )

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ['مخفي', 'hidetag', 'notificar']
handler.tags = ['group']
handler.command = /^(مخفي|hidetag|notificar)$/i
handler.group = true
handler.admin = true

export default handler