// plugins/antilink.js
// ♡ Raiden Shogun - مضاد الروابط 🔗

let linkRegex  = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i;
let linkRegex1 = /whatsapp\.com\/channel\/([0-9A-Za-z]{20,24})/i;

let handler = async (m, { conn, command, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply('❌ هذا الأمر فقط للمجموعات');
    if (!isAdmin && !isOwner) return m.reply('❌ هذا الأمر للمشرفين فقط');

    let chat = global.db.data.chats[m.chat];
    
    let isEnable = ['منع_الروابط', 'تفعيل-مضاد-الروابط'].includes(command);
    
    if (isEnable) {
        chat.antiLink = true;
        m.reply('✅ *تم تفعيل مضاد الروابط*\nسيتم حذف أي رسالة تحتوي على رابط.');
    } else {
        chat.antiLink = false;
        m.reply('❌ *تم إيقاف مضاد الروابط*');
    }
};

handler.before = async (m, { conn, isAdmin, isBotAdmin, isOwner, isROwner, participants }) => {

    if (!m.isGroup) return;
    if (isAdmin || isOwner || m.fromMe || isROwner) return;

    let chat = global.db.data.chats[m.chat];
    if (!chat?.antiLink) return;

    const isGroupLink = linkRegex.exec(m.text) || linkRegex1.exec(m.text);
    if (!isGroupLink) return;

    // ✅ استثناء رابط الجروب
    if (isBotAdmin) {
        try {
            const inviteCode = await conn.groupInviteCode(m.chat);
            const linkThisGroup = `https://chat.whatsapp.com/${inviteCode}`;
            
            // ✅ فحص لو الرسالة فيها نفس كود الجروب
            if (m.text.includes(inviteCode)) return;
            if (m.text.includes(linkThisGroup)) return;
        } catch {}
    }

    // ✅ حذف الرسالة
    await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender } });
};

handler.help = ['منع_الروابط', 'ايقاف_منع_الروابط'];
handler.tags = ['group'];
handler.command = /^(منع_الروابط|ايقاف_منع_الروابط|تفعيل-مضاد-الروابط|ايقاف-مضاد-الروابط)$/i;
handler.group = true;
handler.admin = true;

export default handler;