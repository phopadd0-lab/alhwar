// plugins/channel-info.js
// 🕷️ Raiden Shogun - معلومات القناة 📢

import { generateWAMessageFromContent, proto, prepareWAMessageMedia } from '@whiskeysockets/baileys'

let handler = async (m, { text, conn }) => {
  if (!text) {
    return m.reply(`🕷️ *مـعـلـومـات الـقـنـاة*\n\n🔗 .قناة https://whatsapp.com/channel/xxxx`)
  }

  if (!text.includes('whatsapp.com/channel/')) {
    return m.reply(`❌ رابـط غـيـر صـحـيـح\nتأكد من رابط القناة`)
  }

  let channelId = text.split('channel/')[1]?.split(/[/?]/)[0]
  if (!channelId) return m.reply(`❌ تعذر استخراج معرف القناة`)

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  let res
  try {
    res = await conn.newsletterMetadata('invite', channelId)
  } catch {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    return m.reply(`⚠️ حدث خطأ أثناء جلب بيانات القناة`)
  }

  if (!res?.thread_metadata) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    return m.reply(`❌ لم يتم العثور على بيانات القناة`)
  }

  const meta = res.thread_metadata
  const name = meta.name?.text || 'غير معروف'
  const description = meta.description?.text || 'لا يوجد'
  const subscribers = meta.subscribers_count || 'غير متاح'
  const verification = meta.verification === 'VERIFIED' ? 'مُحققة ✅' : 'غير مُحققة ❌'

  const previewUrl = meta.preview?.direct_path
    ? `https://mmg.whatsapp.net${meta.preview.direct_path}`
    : null

  let imgMsg = null
  if (previewUrl) {
    try {
      imgMsg = await prepareWAMessageMedia(
        { image: { url: previewUrl } },
        { upload: conn.waUploadToServer }
      )
    } catch {}
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: { 
            text: `🕷️ *مـعـلـومـات الـقـنـاة*\n\n📢 *الاسـم:* ${name}\n🆔 *الـمـعـرف:* ${res.id}\n👥 *الـمـشـتـركـيـن:* ${subscribers}\n✅ *الـتـحـقـيـق:* ${verification}\n📝 *الـوصـف:* ${description}`
          },
          footer: { text: '🕷️ Raiden Shogun 🕷️' },
          header: imgMsg ? {
            hasMediaAttachment: true,
            imageMessage: imgMsg.imageMessage
          } : { hasMediaAttachment: false },
          nativeFlowMessage: {
            buttons: [
              {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: '📋 نسخ معرف القناة',
                  copy_code: res.id
                })
              }
            ],
            messageParamsJson: ''
          }
        })
      }
    }
  }, { userJid: conn.user.jid, quoted: m })

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

handler.help = ['قناه']
handler.tags = ['tools']
handler.command = /^(قناه|channel|قناتي)$/i

export default handler