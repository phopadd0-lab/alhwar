// plugins/menu.js
// ✧ هہ‏‏‏‏وآريـﮯ - قائمة جميع الأوامر التلقائية ✨

import { ButtonV2 } from '../core/NIXCODE.js'

let handler = async (m, { conn, usedPrefix }) => {
  try {
    const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
    const user = (await conn.getName(m.sender)) || 'مستخدم'

    // 1. خريطة ترجمة أسماء الأقسام والتصنيفات
    const tagNames = {
      'main': '🏠 القائمة الرئيسية',
      'admin': '🛡️ الإدارة والأدمن',
      'sticker': '🎨 الملصقات والستيكر',
      'game': '🎮 الألعاب والتسلية',
      'downloader': '📥 التحميلات والوسائط',
      'tools': '🛠️ الأدوات والخدمات',
      'anime': '📖 المانجا والأنمي',
      'ai': '🧠 الذكاء الاصطناعي',
      'group': '⚔ النقابات والكلانات',
      'img': '🖼️ الصور والافتارات'
    }

    // ترتيب ثابت للأقسام المعروفة، وأي قسم جديد يتحط في الآخر
    const tagOrder = Object.keys(tagNames)

    // 2. فحص وتجميع الأوامر من الملفات
    let plugins = Object.values(global.plugins).filter(v => !v.disabled)
    let categories = {}

    for (let plugin of plugins) {
      if (!plugin.help) continue
      let tags = plugin.tags || ['أخرى']
      for (let tag of tags) {
        if (!categories[tag]) categories[tag] = []
        let helpList = Array.isArray(plugin.help) ? plugin.help : [plugin.help]
        for (let help of helpList) {
          if (help) categories[tag].push(help)
        }
      }
    }

    let totalCommands = Object.values(categories).flat().length

    // 3. ترتيب الأقسام: المعروفة أولاً بترتيبها، ثم الباقي
    let orderedTags = [
      ...tagOrder.filter(t => categories[t]?.length),
      ...Object.keys(categories).filter(t => !tagOrder.includes(t))
    ]

    // 4. بناء قسم واحد لكل تصنيف - بدون تكرار الصندوق الخارجي
    let sectionsText = orderedTags.map(tag => {
      let tagName = tagNames[tag] || `📁 ${tag}`
      let commands = categories[tag]
      let cmdList = commands.map(cmd => `   ⚡ ${usedPrefix}${cmd}`).join('\n')
      return `『 ${tagName} 』\n${cmdList}`
    }).join('\n\n')

    // 5. رسالة الهيدر - صندوق واحد فقط
    let header = `┌──────[ 👑 هہ‏‏وآريـﮯ 👑 ]──────
│
├─ 👋 أهلاً بك يا ${user}
├─ ⚡ الحالة: متصل
├─ ⏱️ مدة التشغيل: ${getUptime()}
├─ 📊 عدد الأوامر: ${totalCommands}
│
└─────────────────────────`

    let menuText = `${header}\n\n${sectionsText}`

    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } })

    await new ButtonV2(conn)
      .setBody(menuText)
      .setFooter('🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤')
      .setThumbnail(imageUrl)
      .addButton('👑 المطور', '.المطور')
      .addButton('🤖 تنصيب وحدة', '.تنصيب')
      .send(m.chat)

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-Menu] Error:', e)
  }
}

function getUptime() {
  let totalSeconds = process.uptime()
  let hours = Math.floor(totalSeconds / 3600)
  let minutes = Math.floor((totalSeconds % 3600) / 60)
  let seconds = Math.floor(totalSeconds % 60)
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = ['الاوامر', 'menu', 'اوامر', 'القائمة', 'منيو']

export default handler