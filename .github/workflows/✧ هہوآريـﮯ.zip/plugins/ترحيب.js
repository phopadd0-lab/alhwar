// plugins/welcome.js
// ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽v2 - الترحيب والمغادرة 👋

import fetch from 'node-fetch';

const welcomeImage = 'https://file.garden/aauvg01sjleV_ic1/2B.webp'
const goodbyeImage = 'https://file.garden/aauvg01sjleV_ic1/8d6c229e6d9f3cf2b9fa209b08625266.jpg'
const audioUrl = 'https://file.garden/aauvg01sjleV_ic1/%D8%AA%D8%B1%D8%AD%D9%8A%D8%A8.opus'

const handler = async (m, { conn, command, args, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('🔒 هذا الأمر مخصص للجروبات فقط.')

  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  const chat = global.db.data.chats[m.chat]
  const type = (args[0] || '').toLowerCase()
  const enable = command === 'on'

  if (type !== 'welcome') {
    return m.reply(`╭━━ 🌟 *أمـر الـتـرحـيـب* ━━⃝💙
│
│ 🔹 *.on welcome* / *.off welcome*
│
╰━━━━━━━━━━━━━⃝💙`)
  }

  if (!(isAdmin || isOwner)) return m.reply('❌ هذا الأمر للمشرفين فقط.')

  chat.welcome = enable
  return m.reply(`✅ *الترحيب* ${enable ? 'تم التفعيل' : 'تم التعطيل'} بنجاح.`)
}

handler.command = ['on', 'off']
handler.group = true
handler.register = true

handler.before = async (m, { conn, isBotAdmin }) => {
  if (!m.isGroup) return
  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  const chat = global.db.data.chats[m.chat]

  if (!chat.welcome) return
  if (![27, 28, 32].includes(m.messageStubType)) return

  let groupMetadata, groupSize, groupDescription
  try {
    groupMetadata = await conn.groupMetadata(m.chat)
    groupSize = groupMetadata.participants.length
    groupDescription = groupMetadata.desc || "لا يوجد وصف متاح"
  } catch (e) {
    console.error('[Welcome] Error getting group metadata:', e.message)
    return
  }

  // ========== ✨ استخراج معرف المستخدم من LID ==========
  let rawParam = m.messageStubParameters?.[0] || ''
  let userId = ''
  let userName = 'عضو'

  try {
    if (rawParam.startsWith('{')) {
      const parsed = JSON.parse(rawParam)
      userId = parsed.id || '' // هذا هو LID
      if (parsed.phoneNumber) {
        userName = await conn.getName(parsed.phoneNumber)
      }
      if (!userName || userName.match(/^\d+$/)) {
        userName = await conn.getName(userId)
      }
      if (!userName || userName.match(/^\d+$/)) {
        userName = parsed.username || 'عضو'
      }
    } else {
      userId = rawParam
      userName = await conn.getName(userId)
      if (!userName || userName.match(/^\d+$/)) userName = 'عضو'
    }
  } catch {
    userId = rawParam
    try { userName = await conn.getName(userId) } catch {}
    if (!userName || userName.match(/^\d+$/)) userName = 'عضو'
  }

  if (!userId) userId = m.sender

  // ========== صياغة المنشن ==========
  const userMention = '@' + userId.split('@')[0]

  // ========== ترحيب ==========
  if (m.messageStubType === 27) {
    const txtwelcome = `╭━━ 👋 *تـرحـيـب* ━━⃝💙
│
│ ✨ *مـنـور الـمـجـمـوعـة* ✨
│
│ 👤 *العضو:* ${userMention}
│ 📍 *المجموعة:* ${groupMetadata.subject}
│ 👥 *الأعضاء:* ${groupSize}
│
│ 📝 *الوصف:*
│ ${groupDescription.substring(0, 100)}
│
╰━━━━━━━━━━━━━⃝💙`

    try {
      await conn.sendMessage(m.chat, {
        image: { url: welcomeImage },
        caption: txtwelcome,
        mentions: [userId]
      })

      await conn.sendMessage(m.chat, {
        audio: { url: audioUrl },
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true
      })
    } catch (e) {
      console.error('[Welcome] Error sending welcome:', e.message)
    }
  }

  // ========== مغادرة ==========
  if (m.messageStubType === 28 || m.messageStubType === 32) {
    const txtBye = `╭━━ 😢 *وداعـاً* ━━⃝💙
│
│ 👤 *العضو:* ${userMention}
│ 📍 *المجموعة:* ${groupMetadata.subject}
│ 👥 *الأعضاء:* ${groupSize}
│
│ 💔 *نتمنى رؤيتك مرة أخرى*
│
╰━━━━━━━━━━━━━⃝💙`

    try {
      await conn.sendMessage(m.chat, {
        image: { url: goodbyeImage },
        caption: txtBye,
        mentions: [userId]
      })
    } catch (e) {
      console.error('[Welcome] Error sending goodbye:', e.message)
    }
  }
}

export default handler