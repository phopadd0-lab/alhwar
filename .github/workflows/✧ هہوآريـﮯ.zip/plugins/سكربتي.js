// plugins/getbot.js
// ✧ هہ‏‏‏‏وآريـﮯ - نسخة احتياطية للبوت 📦

import { ButtonV2 } from '../core/NIXCODE.js'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import archiver from 'archiver'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
const footerText = '🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤'

// بناء صندوق منسق
function box(title, lines = []) {
  let out = `┌──────[ ${title} ]──────\n│\n`
  for (let l of lines) out += `├─ ${l}\n`
  out += `│\n└─────────────────────────`
  return out
}

let handler = async (m, { conn, usedPrefix, isOwner }) => {
  try {
    // رد نهائي بالشكل الموحد (ButtonV2 لازم فيه زر واحد على الأقل)
    const send = async (body, buttons = [['📦 نسخة جديدة', `${usedPrefix}سكربتي`]]) => {
      let btn = new ButtonV2(conn)
        .setBody(body)
        .setFooter(footerText)
        .setThumbnail(imageUrl)
      for (let [label, cmd] of buttons) btn = btn.addButton(label, cmd)
      await btn.send(m.chat)
    }

    // رسائل التقدم (نص عادي عشان تتعدل)
    const progress = (text, editKey) =>
      conn.sendMessage(m.chat, editKey ? { text, edit: editKey } : { text }, { quoted: m })

    if (!isOwner) {
      await conn.sendMessage(m.chat, { react: { text: '🔒', key: m.key } })
      return send(box('🔒 صلاحية مرفوضة', ['❄️ هذا الأمر للمطور الحقيقي فقط']))
    }

    const botFolderPath = path.join(__dirname, '../')
    const zipFilePath = path.join(__dirname, '../bot_files.zip')

    if (!fs.existsSync(botFolderPath)) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      return send(box('❌ خطأ', ['مجلد البوت غير موجود', `📂 المسار: ${botFolderPath}`]))
    }

    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } })

    let initialMessage = await progress(box('📦 نسخة احتياطية', ['📂 جاري قراءة ملفات البوت...']))

    // حذف ملف ZIP قديم لو موجود
    if (fs.existsSync(zipFilePath)) {
      try { fs.unlinkSync(zipFilePath) } catch {}
    }

    let zippingMessage = await progress(box('🔄 جاري الضغط', ['⏳ يتم الآن إنشاء ملف ZIP...']), initialMessage.key)

    // إنشاء ملف ZIP
    let sizeMB
    try {
      sizeMB = await new Promise((resolve, reject) => {
        const output = fs.createWriteStream(zipFilePath)
        const archive = archiver('zip', { zlib: { level: 9 } })

        output.on('close', () => resolve((archive.pointer() / 1024 / 1024).toFixed(2)))
        archive.on('error', reject)

        archive.pipe(output)
        archive.glob('**/*', {
          cwd: botFolderPath,
          ignore: [
            'node_modules/**',
            '.npm/**',
            'JadiBots/**',
            'GataJadiBot/**',
            '2BSubBot/**',
            'tmp/**',
            '*.zip',
            '.git/**',
            'auth_info_baileys/**',
            'session/**'
          ]
        })
        archive.finalize()
      })
    } catch (err) {
      console.error('[هہ‏‏وآريـﮯ-GetBot] Archiver error:', err)
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      return send(box('❌ فشل الضغط', [err.message]))
    }

    let sendingMessage = await progress(box('📤 جاري الإرسال', [
      '✅ تم إنشاء ملف ZIP بنجاح',
      `📁 الحجم: ${sizeMB} MB`,
      '⏳ يتم الآن إرسال الملف...'
    ]), zippingMessage.key)

    try {
      await conn.sendMessage(m.chat, {
        document: fs.readFileSync(zipFilePath),
        mimetype: 'application/zip',
        fileName: '✧ هہ‏‏وآريـﮯ.zip'
      }, { quoted: m })

      try { fs.unlinkSync(zipFilePath) } catch {}

      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
      await send(box('✅ تم بنجاح', [
        'تم إرسال النسخة الاحتياطية',
        'تم حذف الملف المؤقت'
      ]))
    } catch (sendErr) {
      try { fs.unlinkSync(zipFilePath) } catch {}
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      await send(box('❌ فشل الإرسال', [sendErr.message, '💡 الحل: الملف كبير جداً']))
    }

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-GetBot] Error:', e)
  }
}

handler.help = ['سكربتي']
handler.tags = ['owner']
handler.command = ['سكربتي', 'getbot', 'نسخه']
handler.owner = true

export default handler