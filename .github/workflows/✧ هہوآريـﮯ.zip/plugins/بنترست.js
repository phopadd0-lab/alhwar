// plugins/pinterest.js
// ✧ هہ‏‏‏‏وآريـﮯ - Pinterest 📌

import { ButtonV2 } from '../core/NIXCODE.js'
import axios from 'axios'
import { execFile } from 'child_process'
import { promisify } from 'util'
import { unlinkSync, existsSync, statSync } from 'fs'
import { join } from 'path'
import { tmpdir } from 'os'
import { proto, generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys'

const execFileAsync = promisify(execFile)
const YTDLP_PATH = '/home/container/yt-dlp'
const COOKIES_PATH = '/home/container/cookies/pinterest.txt'

const imageUrl = 'https://f.top4top.io/p_3923tn33r0.jpg'
const footerText = '🖤 ⚡ هہ‏‏وآريـﮯ ⚡ 🖤'

// بناء صندوق منسق
function box(title, lines = []) {
  let out = `┌──────[ ${title} ]──────\n│\n`
  for (let l of lines) out += `├─ ${l}\n`
  out += `│\n└─────────────────────────`
  return out
}

// ═══════════════════════════════════════
// سكرابر Pinterest
// ═══════════════════════════════════════
const PINTEREST_BASE = 'https://www.pinterest.com'
const PINTEREST_SEARCH_PATH = '/resource/BaseSearchResource/get/'
const PINTEREST_HEADERS = {
  accept: 'application/json, text/javascript, */*, q=0.01',
  referer: 'https://www.pinterest.com/',
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
  'x-app-version': 'a9522f',
  'x-pinterest-appstate': 'active',
  'x-pinterest-pws-handler': 'www/[username]/[slug].js',
  'x-requested-with': 'XMLHttpRequest'
}

async function getPinterestCookies() {
  try {
    const res = await axios.get(PINTEREST_BASE, { timeout: 15000 })
    const setCookies = res.headers['set-cookie']
    if (!setCookies) return null
    return setCookies.map(c => c.split(';')[0].trim()).join('; ')
  } catch {
    return null
  }
}

async function searchPinterest(query, needed = 30) {
  const images = []
  const cookies = await getPinterestCookies()
  if (!cookies) return images

  let bookmarks = ['']
  let attempts = 0
  const maxAttempts = 10

  while (images.length < needed && bookmarks.length && attempts < maxAttempts) {
    attempts++
    try {
      const params = {
        source_url: `/search/pins/?q=${encodeURIComponent(query)}`,
        data: JSON.stringify({
          options: { isPrefetch: false, query, scope: 'pins', bookmarks, page_size: 50 },
          context: {}
        }),
        _: Date.now()
      }

      const { data } = await axios.get(`${PINTEREST_BASE}${PINTEREST_SEARCH_PATH}`, {
        headers: { ...PINTEREST_HEADERS, cookie: cookies },
        params,
        timeout: 15000
      })

      const results = data?.resource_response?.data?.results?.filter(v => v?.images?.orig?.url) || []
      if (!results.length) break

      for (const r of results) {
        images.push(r.images.orig.url)
        if (images.length >= needed) break
      }

      const nextBookmark = data?.resource_response?.bookmark
      if (!nextBookmark || nextBookmark === '-end-') break
      bookmarks = [nextBookmark]
    } catch {
      break
    }
  }

  return [...new Set(images)].slice(0, needed)
}

// ═══════════════════════════════════════
// Handler
// ═══════════════════════════════════════
let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const react = async (emoji) => {
      try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch {}
    }

    // رد بالشكل الموحد (ButtonV2 لازم فيه زر واحد على الأقل)
    const send = async (body, buttons = [['📌 Pinterest', `${usedPrefix}${command}`]]) => {
      let btn = new ButtonV2(conn)
        .setBody(body)
        .setFooter(footerText)
        .setThumbnail(imageUrl)
      for (let [label, cmd] of buttons) btn = btn.addButton(label, cmd)
      await btn.send(m.chat)
    }

    if (!text) {
      return send(box('📌 Pinterest', [
        `🔍 بحث صور: ${usedPrefix + command} <كلمة>`,
        `📌 تحميل فيديو: ${usedPrefix + command} <رابط>`
      ]), [['🔍 مثال', `${usedPrefix + command} anime`]])
    }

    // ⭐ تحميل فيديو من الرابط
    if (text.includes('pin.it') || text.includes('pinterest.com/pin/')) {
      const url = text.match(/https?:\/\/\S+/)?.[0]
      if (!url) {
        await react('❌')
        return send(box('❌ خطأ', ['الرابط غير صالح']))
      }

      await react('⏳')
      await send(box('📌 تحميل فيديو', ['⏳ جاري تحميل الفيديو...']))

      const outputPath = join(tmpdir(), `pin_${Date.now()}.mp4`)
      try {
        // execFile بدل exec عشان الرابط ما يتنفذش كأمر في الشيل
        await execFileAsync(YTDLP_PATH, [
          '-o', outputPath,
          url,
          '--cookies', COOKIES_PATH,
          '--no-playlist',
          '--force-overwrites',
          '--no-cookies',
          '--sleep-interval', '5',
          '--user-agent', 'Mozilla/5.0'
        ], {
          timeout: 180000,
          env: { ...process.env, PATH: `${process.env.HOME}/.deno/bin:${process.env.PATH}` }
        })

        if (!existsSync(outputPath)) throw new Error('فشل')
        const sizeMB = (statSync(outputPath).size / 1048576).toFixed(2)

        await conn.sendMessage(m.chat, {
          video: { url: outputPath },
          caption: `✅ تم التحميل بواسطة هہ‏‏وآريـﮯ | ${sizeMB} MB`
        }, { quoted: m })
        await react('✅')
      } catch (e) {
        console.error('[هہ‏‏وآريـﮯ-Pinterest] Download error:', e)
        await react('❌')
        await send(box('❌ خطأ', ['فشل التحميل']))
      } finally {
        try { unlinkSync(outputPath) } catch {}
      }
      return
    }

    // ⭐ بحث صور
    await react('🔍')
    await send(box('🔍 بحث', ['⚡ جاري البحث عن الصور...', `📌 ${text}`]))

    const images = await searchPinterest(text, 30)

    if (!images || images.length === 0) {
      await react('❌')
      return send(box('❌ لا توجد نتائج', [`📌 ${text}`]))
    }

    let cards = []

    for (let i = 0; i < images.length; i++) {
      try {
        const imgRes = await axios.get(images[i], {
          responseType: 'arraybuffer',
          headers: { 'User-Agent': 'Mozilla/5.0' },
          timeout: 15000
        })

        const buffer = Buffer.from(imgRes.data)
        if (buffer.length < 1000) continue

        const { imageMessage } = await generateWAMessageContent(
          { image: buffer },
          { upload: conn.waUploadToServer }
        )
        if (!imageMessage) continue

        cards.push({
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: `📸 صورة ${i + 1} | 🔎 ${text}`
          }),
          header: proto.Message.InteractiveMessage.Header.fromObject({
            hasMediaAttachment: true,
            imageMessage
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [{
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({
                display_text: '📌 فتح في Pinterest',
                url: 'https://www.pinterest.com/search/pins/?q=' + encodeURIComponent(text)
              })
            }]
          })
        })
      } catch {
        continue
      }
    }

    if (cards.length === 0) {
      await react('❌')
      return send(box('❌ خطأ', ['فشل تحميل الصور']))
    }

    // الصور في كاروسيل (ButtonV2 ما بيدعمش الكاروسيل)
    const finalMessage = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: { message: { interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.create({
          text: box('🔍 نتائج Pinterest', [`⚡ البحث: ${text}`, `📸 ${cards.length} صورة`])
        }),
        footer: proto.Message.InteractiveMessage.Footer.create({ text: footerText }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
      }) } }
    }, { quoted: m })

    await conn.relayMessage(m.chat, finalMessage.message, { messageId: finalMessage.key.id })
    await react('✅')

  } catch (e) {
    console.error('[هہ‏‏وآريـﮯ-Pinterest] Error:', e)
    try {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    } catch {}
  }
}

handler.help = ['بنترست']
handler.tags = ['downloader']
handler.command = ['بنترست', 'بينترست', 'بينتر', 'pinterest']

export default handler