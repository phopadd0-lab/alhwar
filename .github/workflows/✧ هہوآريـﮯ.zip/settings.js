
import { unwatchFile, watchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import fs from 'fs'
import fetch from 'node-fetch'
import axios from 'axios'
import moment from 'moment-timezone'

//حط lid بتاعك من امر lid
global.owner = ['201229982764@lid', '245406596391129@lid']

// ========== المطورين ==========
global.mods = []
global.prems = []

// ========== إعدادات البوت ==========
global.baileys = '@whiskeysockets/baileys'
global.botName = 'هہوآريـﮯ'
global.botNameShort = 'هہوآريـﮯ'
global.watermark = 'هہوآريـﮯ'

// ========== المكتبات العامة ==========
global.fetch = fetch
global.axios = axios
global.moment = moment
global.fs = fs

// ========== إعدادات البوت ==========
global.packname = 'هہوآريـﮯ'
global.author = 'هہوآريـﮯ'

global.multiplier = 85

// اكتب رقمك هنا الي عايز تربط بي البوت من دون + او فواصل 
global.botNumberCode = "963989296824"

// ========== القنوات ==========
global.ch = {
  ch1: '@newsletter',
  ch2: '@newsletter'
}

// روابط  السوشيال ميديا بتاعتي 
global.yt = ''
global.ig = ''
global.md = ''
global.fb = ''
global.tk = ''
global.paypal = ''
global.soporteGB = ''

//  ٤١٤×٧٣٦ صور الخطاء لو عايز تغيره بس عشان تكون عارف لزما تكون الصور بي ابعاد مثلا
global.dfailPool = [
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg',
    'https://f.top4top.io/p_3923tn33r0.jpg'
]

// ========== رسائل dfail ==========
global.dfailMessages = {
    rowner: '❌ *المطور فقط*',
    owner: '❌ *المطور فقط*',
    mods: '❌ *القادة فقط*',
    premium: '⭐ *بريميوم فقط*',
    group: '👥 *جروبات فقط*',
    private: '📱 *خاص فقط*',
    admin: '👑 *مشرفين فقط*',
    botAdmin: '🤖 *البوت مش أدمن*',
    unreg: '📝 *غير مسجل*',
    restrict: '🚫 *معطل حالياً*'
}

// ========== زخرفة dfail ==========
global.dfailTitle = 'هواري'
global.dfailDesc = 'هواري'
global.dfailUrl = 'https://github.com/ALHWARy'

// ========== مراقبة الملف ==========
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})